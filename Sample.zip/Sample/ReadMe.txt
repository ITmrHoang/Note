UniKey API Sample
===============================================================



Supported enviroments
---------------------------------------------------------------
Programming Language: C
Platform: ubuntu8.04 
APIs: all UniKey APIs, ver 2.1.0.0

Trademarks
---------------------------------------------------------------
SecuTech Solution Inc. All rights reserved.






