// UniKeySample.cpp : Defines the entry point for the console application.
//

//#include "StdAfx.h"

#include "UniKey.h"

#include <stdio.h>
#include <string.h>

void UniKeySample()
{
	WORD handle[16], p1, p2, p3, p4;
	DWORD retcode, lp1, lp2;

	//get version
	retcode = UniKey_Get_Version(&handle[0], &lp1);
	if (retcode)
	{
		printf("UniKey_Get_Version error code: %d \n", retcode);
		//return;
	}
	printf("UniKey lib ver: %d\n", (int)lp1);

	// find dongle
	lp1 = 10, lp2 = 10;
	retcode = UniKey_Find(&handle[0], &lp1, &lp2);
	if (retcode)
	{
		printf("UniKey_Find error code: %d \n", retcode);
		//return;
	}

	//get type
    lp1=0 ; 
	retcode = UniKey_Get_Type(&handle[0], &lp1) ; 
	if (retcode)
	{
		printf("UniKey_Get_Type error code: %d \n", retcode);
		//return;
	}
	printf("UniKey type : %d\n" , lp1) ; 

	// //return the hardware ID (HID)                             
	printf("Find UniKey: %08X\n", lp1);
	
	UniKey_Get_Dongle_Location(&handle[0], &lp1);
	printf("UniKey_Get_Dongle_Location: %08X(%d.%d.%d.%d)\n", lp1, lp1>>24&0xFF, lp1>>16&0xFF, lp1>>8&0xFF, lp1&0xFF);
	// open dongle

	p1 = 20110;	// passwords
	p2 = 22513;
	p3 = 29778;
	p4 = 6714;
	retcode = UniKey_User_Logon(&handle[0], &p1, &p2);
	if (retcode)
	{
		printf("UniKey_User_Logon error code: %d \n", retcode);
		//return;
	}
	else {
		printf("UniKey_User_Logon is successfull \n");
	}

	retcode = UniKey_Vender_Logon(&handle[0], &p1, &p2, &p3, &p4);
	if (retcode)
	{
		printf("UniKey_Vender_Logon error code: %d \n", retcode);
		//return;
	}
	else {
		printf("UniKey_Vender_Logon is successfull \n");
	}
}

int main()
{
	int nRetCode = 0;

	UniKeySample();
	return nRetCode;
}


